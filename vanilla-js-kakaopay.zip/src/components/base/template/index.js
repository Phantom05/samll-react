export { default as PlainTemplate } from './PlainTemplate';
