export { default as WordGame } from './WordGame';
export { default as ResultScreen } from './ResultScreen';
