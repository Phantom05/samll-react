export default {
  items: [],
  gameResult: null,
};
